# Infomation
`程序简介`: 南京大学 袁洪涛组 超连续激光器光电流Mapping控制软件

`运行要求`: Windows 10, LabVIEW2020(x64) Runtime, LabVIEW 488组件, AmScope软件

`开发环境`: LabVIEW2020(x64)

`帮助文档`: [AmScope](./doc/AmScopeSetup_v4.11.17864.zip), [488组件](./doc/ni-488.2_20.0_online_repack2.exe), [LabVIEW2020(x64)](./doc/ni-labview-2020-runtime-engine_20.0_online.exe)

`开发时间`: 2020年10月起

`软件作者`: zzudongxiang@163.com

# V1.0

```
+ 可通过旋转轴与位移轴进行光电流Mapping
+ 通过超连续激光器实现不同波长, 不同偏振角器件光电流测试
```


